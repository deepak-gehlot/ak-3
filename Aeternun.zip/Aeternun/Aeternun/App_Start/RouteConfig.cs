﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace Aeternun
{
    public class RouteConfig
    {
        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");
            routes.MapRoute(
           name: "Login",
           url: "Login/{action}",
           defaults: new { controller = "Login" }
       );
            routes.MapRoute(
            name: "Registration",
            url: "Registration/{action}",
            defaults: new { controller = "Registration" }
        );
            routes.MapRoute(
          name: "App",
          url: "Home/{action}",
          defaults: new { controller = "Home" }
      );
        routes.MapRoute(
                      name: "ViewAllContact",
                      url: "ViewAllContact/{action}",
                      defaults: new { controller = "ViewAllContact" }
                  );
             routes.MapRoute(
                      name: "Dashboard",
                      url: "Dashboard/{action}",
                      defaults: new { controller = "Dashboard" }
                  );
        routes.MapRoute(
                      name: "AddContact",
                      url: "AddContact/{action}",
                      defaults: new { controller = "AddContact" }
                  );
              routes.MapRoute(
                      name: "ContactDetails",
                      url: "ContactDetails/{action}",
                      defaults: new { controller = "ContactDetails" }
                  );


            routes.MapRoute(
               name: "Default",
               url: "{*url}",
               defaults: new { controller = "Home", action = "Index", id = UrlParameter.Optional }
           );

           
      //      routes.MapRoute(
      //    name: "WorkOrder",
      //    url: "WorkOrder/{action}",
      //    defaults: new { controller = "WorkOrder" }
      //);


        }
    }
}
