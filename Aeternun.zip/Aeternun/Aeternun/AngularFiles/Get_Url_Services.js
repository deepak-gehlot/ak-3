﻿App.service('GetURL_Services', function ($http) {

    this.api_Url = function () {
      
        var custurl = "http://localhost:62949/";
        //var custurl = "http://localhost:51156/";

        return custurl;
    }

})