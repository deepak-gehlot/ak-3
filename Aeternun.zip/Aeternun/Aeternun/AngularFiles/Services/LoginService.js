﻿App.service('LoginService', function ($http) {

    this.UserLogin = function (model) {
        var request = $http({
            method: 'Post',
            url:'api/Users/UserLogin',
            data:model
        })
        return request;
    }
});