﻿
App.service('AddContactService', function ($http) {

   
    this.AddContact = function (model) {
        var request = $http({
            method: 'Post',
            url:'api/Contacts/PostContact',
            data: model
        })
        return request;
    }

    this.UpdateContact = function (model,id) {
        //console.log("inside services", model);
        var request = $http({
            method: 'Put',
            url:'api/Contacts?id='+id,
            data: model
        })
        return request;
    }

    this.ViewAllContact = function () {
        var request = $http({
            method: 'Get',
            url:'api/Contacts/GetAllContact'
        })
        return request;
    }

    this.GetallContact = function (id) {
       
        var request = $http({
            method: 'Get',
            url:'api/Contacts/GetContactbyId?id=' + id
        })
        return request;
    }

    this.GetContactDetailbyId = function (id) {
      
        var request = $http({
            method: 'Get',
            url: 'api/Contacts/GetContact?id=' + id
        })
        return request;
    }

    this.Deletecontact = function (id) {
        var request = $http({
            method: 'Delete',
            url: 'api/Contacts?id=' + id
          
        })
        return request;
    }
    
    this.DeleteSelectedcontact = function (model) {
        var data = { ContactId: model }
        var request = $http({
            method: 'Post',
            url: 'api/Contacts/Deleteselectedcontact',
            data: data
        })
        return request;
    }
    
    this.savenote = function (data) {
        var request = $http({
            method: 'Post',
            url: 'api/Notes',
            data: data
        })
        return request;
    }

    this.Getnotesdetail = function () {
        var request = $http({
            method: 'Get',
            url: 'api/Notes/Getallnote'
        })
        return request;
    }
});