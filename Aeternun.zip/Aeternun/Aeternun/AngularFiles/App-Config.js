﻿
(function () {
    'use strict';

    App.config(function ($stateProvider, $urlRouterProvider, $locationProvider, cfpLoadingBarProvider, $httpProvider) {


       $stateProvider
      .state('Login', {
                  url: '/Login',
                  templateUrl: 'Login/Login',
                  controller: "LoginCtrl",
      })
       .state('Registration', {
           url: '/Registration',
           templateUrl: 'Registration/Registration',
           controller: "RegistrationCtrl",
       }).state('App', {
           url: '/App',
           templateUrl: 'Home/Home',
           controller:  "HomeCtrl"
       }).state('App.Dashboard', {  
           url: '/Dashboard',
           templateUrl: 'Dashboard/Dashboard',
           controller: "DashboardCtrl",
       }).state('App.AddContact', {
           url: '/AddContact',
           templateUrl: 'AddContact/AddContact',
           controller: "AddContactCtrl",
       }).state('App.ViewAllContact', {
           url: '/Contacts',
           templateUrl: 'ViewAllContact/ViewAllContact',
           controller: "ViewContactCtrl",
       }).state('App.ContactDetails', {
           url: '/ContactDetails:ConId',
           templateUrl: 'ContactDetails/ContactDetails',
           controller: "ContactDetailCtrl",
       })
       $locationProvider.hashPrefix('!').html5Mode(true);
       cfpLoadingBarProvider.includeSpinner = true;
       $urlRouterProvider.otherwise('/Login');
    })
})(); 

App.run(function ($rootScope, $stateParams, $location, localStorageService, cfpLoadingBar) {
    
    $rootScope.$on('$stateChangeStart', function (event, toState, toParams, fromState, fromParams) {
        $rootScope.uistate = toState.name;
          if (localStorageService.get('userdetails')) {
                    var data = localStorageService.get('userdetails');

                    if ($location.path() !== 'Login' && !data) {
                      
                        $location.path('Login');
                    }
                    else {
                        if ($location.path() == 'Login' && data) {
                           
                            $location.path('App');
                        }
                    }
                } else {
                    $location.path('Login');
                }
          cfpLoadingBar.start();
        
            });

    $rootScope.$on('$stateChangeSuccess', function (event, toState, toParams, fromState, fromParams) {
      
             cfpLoadingBar.complete();
            });
});


