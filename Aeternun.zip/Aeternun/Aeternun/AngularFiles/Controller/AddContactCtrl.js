﻿
App.controller('AddContactCtrl', function ($scope, $state, $location, $rootScope, AddContactService, localStorageService, CountryListService) {
    var self = this;

    $scope.Model = {};
    $scope.message = '';
    var userdata = localStorageService.get('userdetails');
   
  
    $scope.AddContactDetails = function (models, id)
    {
        var buttontype = id;
        var currentdate = new Date();
        var crntdate = currentdate.getDate();
        var crntmonth = currentdate.getMonth() + 1;
        var crntyear = currentdate.getFullYear();
        createddate = crntyear + '-' + crntmonth + '-' + crntdate;
        isdeleted = false;
        $scope.Model.IsDeleted = false;
        $scope.Model.CreatedDate = createddate;
        var data = $scope.Model;
        console.log(data);
        alert(createddate);
        AddContactService.AddContact(data).success(function (data) {

            $scope.Model = {};
      
            if (data == null || data == '') {
               swal('Oops..', 'Unable to process.', 'error');
            }
            else {
                swal('Good job', 'Contact add successfully.', 'success');
                if (buttontype == '1')
                {
                    $state.go('App.ViewAllContact');
                }
            }
        }).error(function () {
           
           swal('Oops..','Something is not right.','error');
            $scope.Model = {};
        });
    }



    GetCountryList();
    function GetCountryList()
    {
        CountryListService.GetCountryList().success(function(data){
            $scope.Countrylist = data;
         
        }).error(function(data){

        })
    }

   
    $scope.GetstateListByCountryId=function(id) {
      
            CountryListService.GetstateList(id).success(function (data) {
            $scope.Statelist = data;
         
        }).error(function (data) {

        })
    }

    $scope.GetCityListByStateId = function (id) {

            CountryListService.GetCityList(id).success(function (data) {
            $scope.Citylist = data;
         
        }).error(function (data) {

        })
    }

    $scope.updatecontact = function ()
    {
      
    }




    $scope.handle = function (e) {
       
        document.getElementById('date1223').value = "";
        $("#date1223").focus();
    }

});