﻿
App.controller('ViewContactCtrl', function ($scope,$window, $state, $location, $rootScope, $stateParams, AddContactService, localStorageService, CountryListService) {
   
    $scope.inputdisabled = true;
    $scope.hidedatepicker = true;

  $scope.viewallcontact=function() {
        AddContactService.ViewAllContact().success(function (data) {
            $scope.Model = data;
        }).error(function () {
            swal('Oops..', 'Something is not right.', 'error');
            //$scope.Model = {};
        });
    }
  $scope.viewallcontact();
    $scope.Search = function () {
        angular.forEach($scope.Model, function (itm) {
            itm.selected = $scope.isallcontactselected;

        });
    }

    $scope.Action = function (actionid)
    {
        if (actionid == 1)
        { }
        else if (actionid == 2)
        { }
        else if (actionid == 3)
        { }
        else if (actionid == 4) {
            var selecteditem = [];
            var selectlist = $scope.Model;
            for (i = 0; i < selectlist.length; i++) {
                if (selectlist[i].selected == true) {
                    selecteditem.push(selectlist[i].ContactId);
                }
            }
            AddContactService.DeleteSelectedcontact(selecteditem).success(function (data) {
                swal('God job.', 'Contact Deleted Successfully.', 'success');
                $state.go('App.ViewAllContact');
            }).error(function (data) {

                swal('Ooops.', 'Something is Not Right.', 'error');
            });
        }
    }

    $scope.printpage= function()  {
        window.print();
    }


    GetCountryList();
    GetAllstateList();
    GetAllCityList();


    $scope.GetContactDetail = function (id)
    {
        $scope.inputdisabled = true;
        $scope.hidedatepicker = true;
        $scope.hidetextbox = false;
        AddContactService.GetallContact(id).success(function (data) {
            $scope.contact = data;
            var dobdate = data.Dob;
            var dobsplit = dobdate.split('T');
            var dateofbirth = dobsplit[0].split('-');
            var currentdateofbirth = dateofbirth[2] + '/' + dateofbirth[1] + '/' + dateofbirth[0];
            var annudate = data.AnniversaryDate;
            var annusplit = annudate.split('T');
            var annuversrydate = annusplit[0].split('-');
            var currentannudate = annuversrydate[2] + '/' + annuversrydate[1] + '/' + annuversrydate[0];
            $scope.contact.Dob1 = currentdateofbirth;
            $scope.contact.AnniversaryDate1 = currentannudate;
           
          }).error(function (data){
        
        });
    }

  
    function GetCountryList() {
        CountryListService.GetCountryList().success(function (data) {
            $scope.Countrylist = data;
        }).error(function (data) {

        })
    }


    $scope.GetstateListByCountryId = function (id) {

        CountryListService.GetstateList(id).success(function (data) {
            $scope.Statelist = data;
        }).error(function (data) {

        })
    }

    $scope.GetCityListByStateId = function (id) {

        CountryListService.GetCityList(id).success(function (data) {
            $scope.Citylist = data;
        }).error(function (data) {

        })
    }


    function GetAllstateList() {
        CountryListService.GetAllstateList().success(function (data) {
            $scope.Statelist = data;
        }).error(function (data) {

        })
    }

    function GetAllCityList() {
        CountryListService.GetAllCtiyList().success(function (data) {
            $scope.Citylist = data;
        }).error(function (data) {

        })
    }

    $scope.DisableFields = function () {
        $scope.inputdisabled = true;
    }
      
    $scope.edit = function ()
    {
      
        $scope.hidedatepicker = false;
        $scope.hidetextbox = true;
        $scope.inputdisabled = false;
     //   $(".init").removeAttr("disabled");
        $("#phonework option[value='? object:null ?']").remove();
        $("#faxwork option[value='? object:null ?']").remove();
     
    }

    $scope.updatecontact = function (models) {
       
        var buttontype = id;
        console.log(models);
        var id = $scope.contact.ContactId;
        AddContactService.UpdateContact(models,id).success(function (data) {

            $scope.contact = {};
            if (data == null || data == '') {
                swal('Oops..', 'Unable to process.', 'error');
                document.getElementById('HideModal').click();

            }
            else {
                swal('Good job', 'Contact Update successfully.', 'success');
                document.getElementById('HideModal').click();
                //$scope.go = function () {
                //    $timeout(function () {
                //        angular.element('#HideModal').trigger('click');
                //    }, 0);
                //};
                $scope.viewallcontact();
            }
        }).error(function () {
            swal('Oops..', 'Something is not right.', 'error');
            document.getElementById('HideModal').click();
            $scope.contact = {};
        });
    }

});