﻿App.directive('uniqueemailid', function ($http) {
    return {
        restrict: 'A',
        require: 'ngModel',
        link: function (scope, element, attrs, ngModel) {

            element.bind('blur', function (e) {
                var data = {
                    "EmailId": element.val()
                }
              
             
                $http({
                    method: "Post",
                    url:  '/api/Contacts/UniqueEmailId/',
                    data: JSON.stringify(data)
                }).success(function (data) {
                    if (data.length > 0) {
                        ngModel.$setValidity('uniqueemailid', false);
                       
                    } else {
                        ngModel.$setValidity('uniqueemailid', true);
                       
                    }

                });

            });
        }
    };
})