﻿App.directive('uniqueusername', function ($http) {
    return {
        restrict: 'A',
        require: 'ngModel',
        link: function (scope, element, attrs, ngModel) {

            element.bind('blur', function (e) {
                var data = {
                    "UserName": element.val()
                }
              
                $http({
                    method: "Post",
                    url: '/api/Users/UserExists/',
                    data: JSON.stringify(data)
                }).success(function (data) {
                   // alert(data[0].UserName);
                    if (data.length>0) {
                        ngModel.$setValidity('uniqueusername', false);
                      //  swal('Try Again', 'Username already in use.');
                        //alert(data.Response + 'true');
                    } else {
                        ngModel.$setValidity('uniqueusername', true);
                      //  alert(data.Response + 'false');
                    }

                });

            });
        }
    };
})



