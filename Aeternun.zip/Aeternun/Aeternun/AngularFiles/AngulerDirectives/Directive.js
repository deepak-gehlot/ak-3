﻿
App.directive('heading', function () {
    return {
        replace:true,
        template: '<header><h3>Directive Demo</h3></header>'

    };
});

App.directive("passwordVerify", function () {
    return {
        require: "ngModel",
        scope: {
            passwordVerify: '='
        },
        link: function (scope, element, attrs, ctrl) {
          
            scope.$watch(function () {
                var combined;
               
                if (scope.passwordVerify || ctrl.$viewValue) {
                    combined = scope.passwordVerify + '_' + ctrl.$viewValue;
                }
                return combined;
            }, function (value) {
                if (value) {
                    ctrl.$parsers.unshift(function (viewValue) {
                        var origin = scope.passwordVerify;
                        if (origin !== viewValue) {
                            ctrl.$setValidity("passwordVerify", false);
                            return undefined;
                        } else {
                            ctrl.$setValidity("passwordVerify", true);
                            return viewValue;
                        }
                    });
                }
            });
        }
    };
});

App.directive('allowOnlyNumbers', function () {
    return {
        link: function (scope, elm) {
           
            elm.on('keydown', function (event) {

                if (event.which == 64 || event.which == 16) {
                    // to allow numbers  
                    return false;
                } else if (event.which >= 48 && event.which <= 57) {
                    // to allow numbers 

                    return true;
                } else if (event.which >= 96 && event.which <= 105) {
                    // to allow numpad number  

                    return true;
                } else if ([08, 13, 45, 46, 27, 37, 38, 39, 40].indexOf(event.which) > -1) {
                    // to allow backspace, enter, escape, arrows  

                    return true;
                } else {
                    event.preventDefault();
                    // to stop others  
                    return false;
                }

            });
        }
    }
});

var INTEGER_REGEXP = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;                 
App.directive('validemail', function () {
    
    return {
        require: 'ngModel',
        link: function (scope, elm, attrs, ctrl) {
         
            ctrl.$parsers.unshift(function (viewValue) {
                
                if (INTEGER_REGEXP.test(viewValue)) {
                    // it is valid
                    ctrl.$setValidity('validemail', true);
                    return viewValue;
                    
                } else {
                    // it is invalid, return undefined (no model update)
                    ctrl.$setValidity('validemail', false);
                    return undefined;
                   
                } 
            });
        }
    };
});

App.directive("phoneNumberValidator", function () {
    
    return {
        require: "ngModel",
        restrict: "A",
        link: function (scope, elem, attrs, ctrl) {
            var state = 0;
           
            elem.on('keydown', function (event) {
                if (event.which == 64 || event.which == 16) {
                    // to allow numbers  
                    return false;
                } else if (event.which >= 46 && event.which <= 57) {
                    // to allow numbers 
                    state = 1;
                  
                    return true;
                } else if (event.which >= 96 && event.which <= 105) {
                    // to allow numpad number
                    state = 1;
                    return true;
                } else if ([08,13, 27,46,37, 38, 39, 40].indexOf(event.which) > -1) {
                    // to allow backspace, enter, escape, arrows  
                    return true;
                    state = 1;
                } else {
                    event.preventDefault();
                    // to stop others  
                    return false;
                }
            });
            if (state == 1) {
                var domElement = elem[0]; // Get DOM element
                var phoneNumberRegex = new RegExp("\\d{3}\\-\\d{3}\\-\\d{4}"); // Phone number regex
                var cursorIndex; // Index where the cursor should be

                // Create a parser to alter and validate if our
                // value is a valid phone number
                ctrl.$parsers.push(function (value) {

                    // If our value is non-existent, we return undefined
                    // WHY?: an angular model value should be undefined if it is empty
                    if (typeof value === "undefined" || value === null || value == "") {
                        ctrl.$setValidity('invalidFormat', true); // No invalid format if the value of the phone number is empty
                        return undefined;
                    }

                    // PARSER LOGIC
                    // =compare our value to a modified value after it has
                    // been transformed into a "nice" phone number. If these
                    // values are different, we set the viewValue to
                    // the "nice" phone number. If these values are the same,
                    // we render the viewValue (aka. "nice" phone number)
                    var prevValue, nextValue;

                    prevValue = value;
                    nextValue = value.replace(/[\D]/gi, ""); // Strip all non-digits

                    // Make the "nice" phone number
                    if (nextValue.length >= 4 && nextValue.length <= 6) {
                        nextValue = nextValue.replace(/(\d{3})(\d{3})?/, "$1-$2");
                    } else if (nextValue.length >= 7 && nextValue.length <= 10) {
                        nextValue = nextValue.replace(/(\d{3})(\d{3})(\d{4})?/, "$1-$2-$3");
                    }

                    // Save the correct index where the custor should be
                    // WHY?: we do this here because "ctrl.$render()" shifts
                    // the cursor index to the end of the phone number
                    cursorIndex = domElement.selectionStart;
                    if (prevValue != nextValue) {
                        ctrl.$setViewValue(nextValue); // *Calling this function will run all functions in ctrl.$parsers!
                    } else {
                        ctrl.$render(); // Render the new, "nice" phone number
                    }

                    // If our cursor lands on an index where a dash "-" is,
                    // move it up by one
                    if (cursorIndex == 4 || cursorIndex == 8) {
                        cursorIndex = cursorIndex + 1;
                    }

                    var valid = phoneNumberRegex.test(value); // Test the validity of our phone number
                    ctrl.$setValidity('invalidFormat', valid); // Set the validity of the phone number field
                    domElement.setSelectionRange(cursorIndex, cursorIndex); // Assign the cursor to the correct index

                    return value; // Return the updated value
                });
            }
        }
    }
});
 
App.directive('validatePhone', function () {
  
    return {
        link: function (scope, elm) {
            var state = 0;
       
            elm.on('keydown', function (event) {
               // alert(event.which);
                if (event.which == 64 || event.which == 16 ) {
                    // to allow numbers  
                    return false;
                } else if ((event.which >= 48 && event.which <= 57)) {
                    // to allow numbers 
                 
                    return true;
                } else if (event.which >= 96 && event.which <= 105) {
                    // to allow numpad number  
                  
                    return true;
                } else if ([08, 13,45,27,37, 38, 39, 40].indexOf(event.which) > -1) {
                    // to allow backspace, enter, escape, arrows  
                   
                    return true;
                } else {
                    event.preventDefault();
                    // to stop others  
                    return false;
                }
              

            });
            elm.on('keydown', function (e) {
           
                if (e) {
                    var charCode = e.which;
                    var s = document.getElementById('CreatedDate').value;
                 
                    var i = 0;
                    if (charCode == 08)
                    {
                    }
                    else {
                        for (i = 0; i <= s.length - 1; i++) {
                            if (s.length == 2 && i == 1) {

                                if (s > 12) {
                                    return false;
                                }
                                s = s + "/";

                            }
                            if (i == 4 && s.length == 5) {
                                var d = s.split('/');
                                var dd = d[1];
                                if (dd > 31) {
                                    return false;
                                }
                                s = s + "/";

                            }
                            //if (i == 8 && s.length == 10)
                            //{
                            //    var year = s.split('/');
                            //    var yy = year[2];
                            //    if (yy < 2016)
                            //    {
                            //        return false;
                            //    }
                            //    document.getElementById("CreatedDate").value = '';
                            //}

                        }
                        document.getElementById("CreatedDate").value = s;
                    }
                    //if (e.which == 08) {
                    //}
                    //else {
                        //if (s.length == 13)
                        //{
                        //    document.getElementById("txtMobile").value =s;
                        //}
                    //}
                    
                    //if (charCode > 31 && (charCode < 48 || charCode > 57)) {
                    //    return false;
                    //}
                }
                return true;
            });
           
        }
    }
});

App.directive('calendar', function () {
    return {
        require: 'ngModel',
        link: function (scope, el, attr, ngModel) {

            $(el).datepicker({
                dateFormat: 'yy-mm-dd',
                onSelect: function (dateText) {
                    scope.$apply(function () {
                        ngModel.$setViewValue(dateText);
                    });
                }
            });
        }
    };
})

//app.directive('dateval', function () {
 
//    return {
//        require: 'ngModel',
//        link: function (scope, el, attr, ngModel) {
//            $(el).datepicker({
//                dateFormat: 'yy-mm-dd',
//                onSelect: function (dateText) {
//                    scope.$apply(function () {
                    
//                        var date = new Date();
//                        var yyyy = date.getFullYear().toString();
//                        var mm = (date.getMonth() + 1).toString();
//                        var dd = date.getDate().toString();

//                        var mmChars = mm.split('');
//                        var ddChars = dd.split('');
//                        var datestring = yyyy + '-' + (mmChars[1] ? mm : "0" + mmChars[0]) + '-' + (ddChars[1] ? dd : "0" + ddChars[0]);
//                        if (dateText >= datestring) {
                          
//                           // document.getElementById('startdate1').value='';
//                        }
//                        else {
                         
//                            document.getElementById('startdate1').value = '';
//                            //ngModel.$setViewValue(dateText);
//                        }

//                    });
//                }
//            });
//        }
//    };
//})

App.directive('comparedate', function () {

    return {
        require: 'ngModel',
        scope: {
            comparedate: '='
        },
        link: function (scope, elm, attrs, ctrl) {
            ctrl.$parsers.unshift(function (viewValue) {
                var startdate=scope.comparedate;
                if (startdate <= viewValue) {
                    // it is valid
                    ctrl.$setValidity('comparedate', true);
                    return viewValue;

                } else {
                    // it is invalid, return undefined (no model update)
                    ctrl.$setValidity('comparedate', false);
                    return undefined;

                }
            });
        }
    };
});
App.directive('comparedate1', function () {

    return {
        require: 'ngModel',
        scope: {
            comparedate1: '='
        },
        link: function (scope, elm, attrs, ctrl) {
            ctrl.$parsers.unshift(function (viewValue) {
                var endtdate = scope.comparedate1;
                if (endtdate>= viewValue) {
                    // it is valid
                    ctrl.$setValidity('comparedate1', true);
                    return viewValue;

                } else {
                    // it is invalid, return undefined (no model update)
                    ctrl.$setValidity('comparedate1', false);
                    return undefined;

                }
            });
        }
    };
});


App.directive('validNumber', function () {
    return {
        require: '?ngModel',
        link: function (scope, element, attrs, ngModelCtrl) {
            if (!ngModelCtrl) {
                return;
            }
            ngModelCtrl.$parsers.push(function (val) {
                if (angular.isUndefined(val)) {
                    var val = '';
                }

                var clean = val.replace(/[^-0-9\.]/g, '');
                var negativeCheck = clean.split('-');
                var decimalCheck = clean.split('.');
                if (!angular.isUndefined(negativeCheck[1])) {
                    negativeCheck[1] = negativeCheck[1].slice(0, negativeCheck[1].length);
                    clean = negativeCheck[0] + '-' + negativeCheck[1];
                    if (negativeCheck[0].length > 0) {
                        clean = negativeCheck[0];
                    }
                }
                if (!angular.isUndefined(decimalCheck[1])) {
                    decimalCheck[1] = decimalCheck[1].slice(0, 2);
                    clean = decimalCheck[0] + '.' + decimalCheck[1];
                }
                if (val !== clean) {
                    ngModelCtrl.$setViewValue(clean);
                    ngModelCtrl.$render();
                }
                return clean;
            });

            element.bind('keypress', function (event) {
                if (event.keyCode === 32) {
                    event.preventDefault();
                  
                }
            });
        }
    };
});

App.directive('checkpastdate', function () {
 
    return {
        require: 'ngModel',
        link: function (scope, elm, attrs, ctrl) {

            ctrl.$parsers.unshift(function (viewValue) {
              
                var date = new Date();
                var yyyy = date.getFullYear().toString();
                var mm = (date.getMonth() + 1).toString();
                var dd = (date.getDate()).toString();
                var mmChars = mm.split('');
                var ddChars = dd.split('');
              
                var datestring = yyyy + '-' + (mmChars[1] ? mm : "0" + mmChars[0]) + '-' + (ddChars[1] ? dd : "0" + ddChars[0]);
               
                if (viewValue>=datestring) {
                    // it is valid
                 
                    ctrl.$setValidity('checkpastdate', true);
                    return viewValue;

                } else {
                    // it is invalid, return undefined (no model update)
                
                    ctrl.$setValidity('checkpastdate', false);
                    return undefined;

                }
            });
        }
    };
});

App.directive('datez', function () {
 
    return {
        restrict: 'A',
        require: 'ngModel',
        link: function (scope, element, attrs, ngModelCtrl) {
            element.datetimepicker({
                autoclose: true,
                dateFormat: 'dd/MM/yyyy'
            }).on('changeDate', function (e) {
                ngModelCtrl.$setViewValue(e.date);
                scope.$apply();
            });
        }
    };
});
App.directive('datetimez', function () {
    return {
        restrict: 'A',
        require: 'ngModel',
        link: function (scope, element, attrs, ngModelCtrl) {
            element.datetimepicker({
                autoclose: true,
                pickTime:true,
                dateFormat: 'dd/MM/yyyy hh:mm:ss'
            }).on('changeDate', function (e) {
                ngModelCtrl.$setViewValue(e.date);
                scope.$apply();
            });
        }
    };
});
App.directive('checkpastddate', function () {

    return {
        require: 'ngModel',
        link: function (scope, elm, attrs, ctrl) {
           
            ctrl.$parsers.unshift(function (viewValue) {
                var selecteddate = new Date(viewValue);
                
                var syyyy = selecteddate.getFullYear().toString();
                var smm = (selecteddate.getMonth() + 1).toString();
                var sdd = (selecteddate.getDate()).toString();
                var smmChars = smm.split('');
                var sddChars = sdd.split('');
                var sdatestring = syyyy + '-' + (smmChars[1] ? smm : "0" + smmChars[0]) + '-' + (sddChars[1] ? sdd : "0" + sddChars[0]);
               
              
                var date = new Date();
                var yyyy = date.getFullYear().toString();
                var mm = (date.getMonth() + 1).toString();
                var dd = date.getDate().toString();
                var mmChars = mm.split('');
                var ddChars = dd.split('');
                var datestring = yyyy + '-' + (mmChars[1] ? mm : "0" + mmChars[0]) + '-' + (ddChars[1] ? dd : "0" + ddChars[0]);
             
                if (sdatestring >= datestring) {
                    // it is valid
                   
                    ctrl.$setValidity('checkpastddate', true);
                    return viewValue;

                } else {
                    // it is invalid, return undefined (no model update)
                    ctrl.$setValidity('checkpastddate', false);
                    return undefined;

                }
            });
        }
    };
});

//app.directive('dateTimePicker', function () {
//    return {
//        restrict: 'E',
//        replace: true,
//        scope: {
//            recipient: '='
//        },
//        template:
//          '<div>' +
//          '<input type="text" data-date-format="MM/dd/yyyy HH:mm:ss PP" name="recipientDateTime" data-date-time required>' +
//          '</div>',
//        link: function(scope, element, attrs, ngModel) {
//            var input = element.find('input');
 
//            input.datetimepicker({
//                format: "MM/dd/yyyy HH:mm:ss",
//                showMeridian: true,
//                autoclose: true,
//                todayBtn: true,
//                todayHighlight: true
//            });
 
//            element.bind('blur keyup change', function(){
//                scope.recipient.datetime = input.val();
//            });
//        }
//    }
//});

App.directive('onlycharacter', function () {
    return {
        link: function (scope, elm) {
        
            elm.on('keydown', function (event) {
            
                if ((event.which >= 65 && event.which <= 90)) {
                    // to allow numpad number 
                 
                    return true;
                }
                else if ([08, 35, 36, 13, 45, 27, 32, 37, 38, 2, 3, 39, 40].indexOf(event.which) > -1) {
                    // to allow backspace, enter, escape, arrows  
                  

                    return true;
                }
                else if ((event.which >= 48 && event.which <= 57) || (event.which >= 96 && event.which <= 105)) {
                 
                    return false;
                   
                }
                else {
                    event.preventDefault();
                    // to stop others  
                    return false;
                }

            });
        }
    }
});










