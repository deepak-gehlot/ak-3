﻿using Aeternun.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Data;


namespace Aeternun.BusinessLayer
{
    public class UserLogin
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["DatabaseContext"].ToString());
        
        public int UserLogin(User model)
        {
            int success = 0;
            try
            {
                SqlCommand cmd = new SqlCommand("select UserName,Password from Users where UserName=@UserName and Password=@Password", con);
                cmd.Parameters.AddWithValue("@UserName",model.UserName);
                cmd.Parameters.AddWithValue("@Password", model.Password);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    success = 1;
                }
               
            }
            catch (Exception ex)
            {
                return success;
            }


            return success;
        }
    }
}