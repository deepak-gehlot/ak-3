namespace Aeternun.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class addnote : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Notes",
                c => new
                    {
                        NoteId = c.Long(nullable: false, identity: true),
                        ContactId = c.Long(nullable: false),
                        Subject = c.String(maxLength: 100),
                        addnote = c.String(maxLength: 500),
                    })
                .PrimaryKey(t => t.NoteId);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.Notes");
        }
    }
}
