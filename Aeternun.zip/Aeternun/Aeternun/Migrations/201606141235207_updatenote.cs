namespace Aeternun.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class updatenote : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Notes", "CreatedOn", c => c.DateTime(nullable: false));
        }
        
        public override void Down()
        {
            DropColumn("dbo.Notes", "CreatedOn");
        }
    }
}
