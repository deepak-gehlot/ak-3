namespace Aeternun.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class updatecontact : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Contacts", "CreatedBy", c => c.Int(nullable: false));
            AddColumn("dbo.Contacts", "CreatedDate", c => c.String());
            AddColumn("dbo.Contacts", "IsDeleted", c => c.Boolean(nullable: false));
        }
        
        public override void Down()
        {
            DropColumn("dbo.Contacts", "IsDeleted");
            DropColumn("dbo.Contacts", "CreatedDate");
            DropColumn("dbo.Contacts", "CreatedBy");
        }
    }
}
