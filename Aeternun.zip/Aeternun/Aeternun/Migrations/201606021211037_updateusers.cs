namespace Aeternun.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class updateusers : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Contacts", "CreatedDate", c => c.DateTime(nullable: false));
            AddColumn("dbo.Contacts", "Dob", c => c.DateTime(nullable: false));
            AddColumn("dbo.Contacts", "AnniversaryDate", c => c.DateTime(nullable: false));
        }
        
        public override void Down()
        {
            DropColumn("dbo.Contacts", "AnniversaryDate");
            DropColumn("dbo.Contacts", "Dob");
            DropColumn("dbo.Contacts", "CreatedDate");
        }
    }
}
