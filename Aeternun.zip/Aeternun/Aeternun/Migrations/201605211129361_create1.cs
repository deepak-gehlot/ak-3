namespace Aeternun.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class create1 : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Contacts", "PhoneWork", c => c.String(maxLength: 50));
            AddColumn("dbo.Contacts", "FaxWork", c => c.String(maxLength: 50));
        }
        
        public override void Down()
        {
            DropColumn("dbo.Contacts", "FaxWork");
            DropColumn("dbo.Contacts", "PhoneWork");
        }
    }
}
