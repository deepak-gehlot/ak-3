namespace Aeternun.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Create : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Cities",
                c => new
                    {
                        CityId = c.Int(nullable: false, identity: true),
                        StateId = c.Int(nullable: false),
                        Name = c.String(nullable: false, maxLength: 100),
                    })
                .PrimaryKey(t => t.CityId);
            
            CreateTable(
                "dbo.Contacts",
                c => new
                    {
                        ContactId = c.Long(nullable: false, identity: true),
                        FirstName = c.String(nullable: false, maxLength: 100),
                        LastName = c.String(nullable: false, maxLength: 100),
                        EmailId = c.String(nullable: false, maxLength: 300),
                        Business = c.String(maxLength: 200),
                        Phoneno = c.String(maxLength: 15),
                        Note = c.String(maxLength: 1000),
                        JobTitle = c.String(maxLength: 200),
                        Mobileno = c.String(maxLength: 15),
                        Fax = c.String(maxLength: 15),
                        Dob = c.String(maxLength: 12),
                        Spouse = c.String(maxLength: 100),
                        AnniversaryDate = c.String(maxLength: 12),
                        Address1 = c.String(maxLength: 500),
                        Address2 = c.String(maxLength: 500),
                        CityId = c.Int(nullable: false),
                        StateId = c.Int(nullable: false),
                        CountryId = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.ContactId);
            
            CreateTable(
                "dbo.Countries",
                c => new
                    {
                        CountryId = c.Int(nullable: false, identity: true),
                        Name = c.String(nullable: false, maxLength: 100),
                    })
                .PrimaryKey(t => t.CountryId);
            
            CreateTable(
                "dbo.Sites",
                c => new
                    {
                        SiteId = c.Long(nullable: false, identity: true),
                        CompanyName = c.String(nullable: false),
                        Logo = c.String(maxLength: 100),
                        JobTitle = c.String(),
                        Location = c.String(),
                        JobDescription = c.String(),
                        ResponseURL = c.String(maxLength: 100),
                        ResponseEmail = c.String(maxLength: 50),
                        LastModifiedDate = c.DateTime(nullable: false),
                        Host = c.String(),
                        tenant_TenantId = c.Int(),
                    })
                .PrimaryKey(t => t.SiteId)
                .ForeignKey("dbo.Tenants", t => t.tenant_TenantId)
                .Index(t => t.tenant_TenantId);
            
            CreateTable(
                "dbo.Tenants",
                c => new
                    {
                        TenantId = c.Int(nullable: false, identity: true),
                        Name = c.String(maxLength: 100),
                        Host = c.String(nullable: false),
                        Title = c.String(),
                        Theme = c.String(),
                    })
                .PrimaryKey(t => t.TenantId);
            
            CreateTable(
                "dbo.States",
                c => new
                    {
                        StateId = c.Int(nullable: false, identity: true),
                        CountryId = c.Int(nullable: false),
                        Name = c.String(nullable: false, maxLength: 100),
                    })
                .PrimaryKey(t => t.StateId);
            
            CreateTable(
                "dbo.Users",
                c => new
                    {
                        UserId = c.Int(nullable: false, identity: true),
                        UserName = c.String(nullable: false, maxLength: 100),
                        Password = c.String(nullable: false, maxLength: 50),
                        Hoste = c.String(),
                        FName = c.String(),
                        LName = c.String(),
                        EmailId = c.String(),
                        Mobileno = c.String(),
                    })
                .PrimaryKey(t => t.UserId);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Sites", "tenant_TenantId", "dbo.Tenants");
            DropIndex("dbo.Sites", new[] { "tenant_TenantId" });
            DropTable("dbo.Users");
            DropTable("dbo.States");
            DropTable("dbo.Tenants");
            DropTable("dbo.Sites");
            DropTable("dbo.Countries");
            DropTable("dbo.Contacts");
            DropTable("dbo.Cities");
        }
    }
}
