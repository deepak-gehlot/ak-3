﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Aeternun.Controllers
{
    public class ViewAllContactController : Controller
    {
        // GET: ViewAllContact
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult ViewAllContact()
        {
            return View();
        }
    }
}