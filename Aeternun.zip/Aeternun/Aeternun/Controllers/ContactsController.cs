﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using Aeternun.Models;

namespace Aeternun.Controllers
{
    public class ContactsController : ApiController
    {
        private DatabaseContext db = new DatabaseContext();

        // GET: api/Contacts
        public IQueryable<Contact> GetContacts()
        {
            return db.Contacts;
        }

        // GET: api/Contacts/5
        [ResponseType(typeof(Contact))]
        public IHttpActionResult GetContact(long id)
        {
            var result = from t1 in db.Contacts
                         join t2 in db.States on t1.StateId equals t2.StateId 
                         where  t1.ContactId==id
                         select new { t1.ContactId, t1.FirstName, t1.LastName, t1.EmailId, t1.Phoneno, t1.Business, t2.Name };

            return Ok(result);
        }

        [ResponseType(typeof(Contact))]
        public IHttpActionResult GetContactbyId(long id)
        {
            var result = db.Contacts.Find(id);
           
            return Ok(result);
        }

        [ResponseType(typeof(Contact))]
        public IHttpActionResult GetAllContact()
        {

            var result = from t1 in db.Contacts
                         join t2 in db.States on t1.StateId equals t2.StateId
                         where t1.IsDeleted==false
                         select new { t1.ContactId, t1.FirstName, t1.LastName, t1.EmailId, t1.Phoneno, t1.Business, t2.Name };

            return Ok(result);
        }


        // PUT: api/Contacts/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutContact(long id, Contact contact)
        {
            var success = 0;
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != contact.ContactId)
            {
                return BadRequest();
            }

            db.Entry(contact).State = EntityState.Modified;

            try
            {
             success= db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ContactExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return Ok(success);
        }

        // POST: api/Contacts/UniqueEmailId
        public IHttpActionResult UniqueEmailId(Contact model)
        {
            var user = db.Contacts.Where(e => e.EmailId == model.EmailId);
            if (user == null)
            {
                return NotFound();
            }
            else
            {
                return Ok(user);
            }

        }


        // POST: api/Contacts
        [ResponseType(typeof(Contact))]
        public IHttpActionResult PostContact(Contact contact)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.Contacts.Add(contact);
            db.SaveChanges();
            return CreatedAtRoute("DefaultApi", new { id = contact.ContactId }, contact);
        }
        [HttpPost]
        [ResponseType(typeof(Contactidlist))]
        public IHttpActionResult Deleteselectedcontact(Contactidlist contactid)
         {

             int success = 1;
             for (int i = 0; i < contactid.ContactId.Count;i++ )
             {
                 var id=contactid.ContactId[i];
                 var row = db.Contacts.Single(x => x.ContactId == id);  // Getting the row

                 row.IsDeleted = true;  // Assign the new value
                 try
                 {
                     success = db.SaveChanges();
                 }
                 catch (Exception ex)
                 {
                     success = 0;
                 }
             }
             if (success == 0)
             {
                 return NotFound();
             }
             return Ok();
        }

        // DELETE: api/Contacts/5
        [ResponseType(typeof(Contact))]
        public IHttpActionResult DeleteContact(long id)
        {
           
            int success = 0;
            var row = db.Contacts.Single(x => x.ContactId ==id);  // Getting the row

            row.IsDeleted =true;  // Assign the new value
            try
            {
               success= db.SaveChanges();
            }
            catch (Exception ex)
            {
             
            }
            if (success == 0)
            {
                return NotFound();
            }
            else
            {
                return Ok(success);
            }
        }

     
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool ContactExists(long id)
        {
            return db.Contacts.Count(e => e.ContactId == id) > 0;
        }
    }
}