﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Aeternun.Models
{
    public class Site
    {
        public long SiteId { get; set; }
        [Required]
        public string CompanyName { get; set; }
        [MaxLength(100)]
        public string Logo { get; set; }
        public string JobTitle { get; set; }
        public string Location { get; set; }
        public string JobDescription { get; set; }
        [MaxLength(100)]
        public string ResponseURL { get; set; }
        [MaxLength(50)]
        public string ResponseEmail { get; set; }
        public DateTime LastModifiedDate { get; set; }
        public string Host { get; set; }
        public Tenant tenant { get; set; }
    }
}