﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Aeternun.Models
{
    public class Tenant
    {
        public int TenantId { get; set; }
        [MaxLength(100)]
        public string Name { get; set; }
        [Required]
        public string Host { get; set; }
        public string Title { get; set; }
        public string Theme { get; set; }
    }
}