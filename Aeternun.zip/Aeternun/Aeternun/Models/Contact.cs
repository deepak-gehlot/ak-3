﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Aeternun.Models
{
    public class Contact
    {
        public long ContactId { get; set; }
        [Required]
        [MaxLength(100)]
        public string FirstName { get; set; }
        [Required]
        [MaxLength(100)]
        public string LastName { get; set; }
        [Required]
        [MaxLength(300)]
        public string EmailId { get; set; }
        [MaxLength(200)]
        public string Website { get; set; }
        [MaxLength(200)]
        public string Business { get; set; }
        [MaxLength(15)]
        public string Phoneno { get; set; }
        [MaxLength(1000)]
        public string Note { get; set; }
        [MaxLength (200)]
        public string JobTitle { get; set; }
        [MaxLength(15)]
        public string Mobileno { get; set; }
        [MaxLength(15)]
        public string Fax { get; set; }

        [MaxLength(100)]
        public string Spouse { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime Dob { get; set; }
        public DateTime AnniversaryDate { get; set; }

        [MaxLength (500)]
        public string Address1 { get; set; }
        [MaxLength(500)]
        public string Address2 { get; set; }
        public int CityId { get; set; }
        public int StateId { get; set; }
        public int CountryId { get; set; }
        [MaxLength(50)]
        public string PhoneWork { get; set; }
        [MaxLength(50)]
        public string FaxWork { get; set; }
        [MaxLength(20)]
        public string PostalCode { get; set; }
        public int CreatedBy { get; set; }
    
        public bool IsDeleted { get; set; }
    }
}