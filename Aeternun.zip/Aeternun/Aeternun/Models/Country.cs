﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Aeternun.Models
{
    public class Country
    {
        public int CountryId { get; set; }
        [Required]
        [MaxLength (100)]
        public string Name { get; set; }
    }
}