﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Aeternun.Models
{
    public class User
    {
        public int UserId { get; set; }
        [Required]
        [MaxLength(100)]
        public string UserName { get; set; }
        [Required]
        [MaxLength(50)]
        public string Password { get; set; }
        public int TenantId { get; set; }
   
        public string Hoste { get; set; }
        public string FName { get; set; }
        public string LName { get; set; }
        public string EmailId { get; set; }
        public string Mobileno { get; set; }
        public DateTime CreatedOn { get; set; }
    }
}