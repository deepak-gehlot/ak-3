﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Aeternun.Models
{
    public class Note
    {
        public long NoteId { get; set; }
        public long ContactId { get; set; }
        [MaxLength(100)]
        public string Subject { get; set; }
        [MaxLength(500)]
        public string addnote { get; set; }
        public DateTime CreatedOn { get; set; }
    }
}